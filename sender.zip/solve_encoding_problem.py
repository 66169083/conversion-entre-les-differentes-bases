file = "Capture d’écran 2024-03-07 161857 dè.png "


def encode_caractere(caractere: str):
    caractere_list = ["é", "è", "ç", "à", "ù", "ô", "î", "û", "â", "ï", "ü", ]

    caractere_code = ""
    for i in caractere:
        i = (str(i.encode()))
        caractere_code += i
    return caractere_code

a=encode_caractere(str(file))
for i in a:
    if i=="b'":
        i=i.replace("b'",".")

b=file.encode()
print(b)