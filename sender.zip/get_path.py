def get_path(path):
    number_symbols=0
    symbol_position=[]
    for j,i in enumerate(path):
        if i=="/":
            symbol_position.append(j)
            number_symbols+=1
    path=path[symbol_position[-1]+1:]
    return path