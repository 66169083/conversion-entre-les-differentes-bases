from socket import *
import time ,os,json

ip = ("127.0.0.1", 1234)
client = socket(AF_INET, SOCK_STREAM)
file="cours.pdf"
file=str(file)
files=open(file, "rb")
data=files.read()
file_size=os.path.getsize(file)
connection = True
while connection:
    try:
        client.connect(ip)
        connection = False
    except:
        pass

#client.send(json.dumps(file).encode())
#client.send(str(file_size).encode())
client.sendall(data)
print(len(data))
client.send(b"")
client.send('bonjour'.encode())
client.send((str(file).encode("utf-8")))

files.close()


