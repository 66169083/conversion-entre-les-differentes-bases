from tkinter import *
from tkinter import ttk

root = Tk()
root.configure(bg="gray")
root.geometry("800x800+10+10")
root.minsize(1200,800)
scroll_horizontal=ttk.Scrollbar(root,orient="horizontal")
scroll_vertical=ttk.Scrollbar(root,orient="vertical")
scroll_horizontal.pack(side=BOTTOM,fill=X)
scroll_vertical.pack(side=RIGHT,fill=Y)
send_frame = Frame(root, width=400, height=400)
send_frame.place(x=10, y=45)
receive_frame = Frame(root, width=400, height=400)
receive_frame.place(x=415, y=45)

root.mainloop()


