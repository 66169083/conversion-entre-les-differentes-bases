from customtkinter import *
from tkinter import ttk
from tkinter import *
root=CTk()
root.geometry("600x600")
def fonction(*args):
    pass
list_wifi=[]

combobox=CTkComboBox(root,width=100,height=150,values=list_wifi,state="readonly")
combobox.set("Selectionner un réseau")
combobox.bind("<<ComboboxSelect>>",fonction)
combobox.place(x=50,y=50)
root.mainloop()