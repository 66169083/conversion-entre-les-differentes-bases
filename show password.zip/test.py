from partie_logique import  show_passord as s,qrcode_generator as q
print(s("WIFI EPO"))
q("WPA2","Galaxy","Edouard66")