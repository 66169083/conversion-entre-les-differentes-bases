from subprocess import *
from partie_logique import get_network_names, show_passord


def get_encryption(network_name):
    commande = ["netsh", "wlan", "show", "profile", "name=", str(network_name), "key=", "clear"]
    process = run(commande, capture_output=True, text=True)
    resultat, result = process.stdout, ""
    if show_passord(network_name):
        result = ((resultat.split("Authentification")[1].strip()).split("ÿ")[0].strip()).split(":")[1]
    return result


print(get_encryption("WIFI EPO"))
