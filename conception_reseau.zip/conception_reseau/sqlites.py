

def get_list_sous_reseau(ip_address: str, pas,octet_position, nombre_sous_reseau: int):
    list_sous_reseau, ip, list_oct = [["1", ip_address]], "", ip_address.split(".", 4)
    octet1_value, octet2_value, octet3_value, octet4_value = 0, 0, 0, 0
    for i in range(nombre_sous_reseau-1):
        if octet4_value + pas < 255:
            octet4_value += pas
        else:
            octet4_value=0
        somme=int(list_oct[3-octet_position])+octet4_value
        list_oct[3-octet_position]=str(somme)
        for j in list_oct:
            ip += "." + j
        ip = ip[1:]
        list_sous_reseau.append([str(i + 2), ip])
        ip = ""
        list_oct[3-octet_position]="0"
    return list_sous_reseau
#print(get_list_sous_reseau("192.160.2.0",32,2,10))
import phonenumbers as ph
from phonenumbers import  geocoder,carrier
number="+22670169083"
phone=ph.parse(number)
location=geocoder.description_for_number(phone,"fr")
print(location)
service=ph.parse(number)
print(carrier.name_for_valid_number(service,"fr"))
print()
