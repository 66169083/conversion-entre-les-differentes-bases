def convert_base(number, base):
    t, T, result = [], [], ""
    a, b = int(number), base
    while a != 0:
        T.append(a % b)
        a //= b
    T = T[::-1]
    for i in T:
        t.append(str(i))
    for j in t:
        result += j
    return [result, t]
############################################################
def conversion_start_base_number_end_base(start_base, number, end_base):
    a, b, c, decode_result,   T, t = start_base, number, end_base, 0, [], [f"{i}" for i in range(10)] + ["A", "B", "C", "D", "E", "F"]
    d2, d1 = {f"{t[i]}": f"{i}" for i in range(16)}, {f"{i}": f"{t[i]}" for i in range(16)}
    d2.update(d1)
    if int(number)==0:
        return "0"
    else:

        for i in str(number):
            T.append(d2[i])
        T, decode_result = T[::-1], 0
        for i in range(len(T)):
            decode_result += int(T[i]) * (a ** i)
        division_reste, codage_result = convert_base(decode_result, c)[1], ""
        if c == 10:
            return decode_result
        else:
            for i in division_reste:
                codage_result += d2[i]
            return codage_result