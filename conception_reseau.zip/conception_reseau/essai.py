from customtkinter import *
root=CTk()
root.geometry("600x600")
frame=CTkScrollableFrame(root,width=500,height=500)
pas=0
for i in range(5):

    label = CTkLabel(root, text='bonjour', font=("Helvetica", 19, "bold")).place(relx=0.1, rely=pas+0.1)
    entry = CTkEntry(root, placeholder_text=str(),font=("Helvetica", 19, "bold")).place(relx=0.36,rely=0.1+pas)
    pas += 0.2
root.mainloop()