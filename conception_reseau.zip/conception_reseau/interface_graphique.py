from customtkinter import *
from tkinter import messagebox
import partie_logique as cal
import errors_manager as manage
from change_theme_color import change_theme_color
from VLSM import interface_vlsm



root = CTk()
set_default_color_theme("green")
root.geometry("600x530+5+5")
root.maxsize(600,530)
root.minsize(600,530)
root.title("affiche sous réseau")
colums = ["Réseau N°", "adresse Réseau", "masque sous réseau"]


def fonction1():
    masque_final = entry_masque_final.get()
    masque_intial = entry_masque_intial.get()
    ip_address1 = entry_ip_address1.get()
    return ip_address1, masque_intial, masque_final


def fonction2():
    ip_address2 = entry_ip_address2.get()
    nombre_bits = entry_nombre_bits.get()
    nombre_hotes=entry_nombre_hotes.get()
    return ip_address2, nombre_bits,nombre_hotes


def affiche_sous_reseau_part1():

    verification=manage.manage_part1(fonction1()[0],fonction1()[1],fonction1()[2])
    if verification[0]:
        n=cal.get_nombre_bits_avec_masque(fonction1()[2])-cal.get_nombre_bits_avec_masque(fonction1()[1])
        values = cal.get_list_sous_reseau(fonction1()[0], cal.get_nombre_bits_avec_masque(fonction1()[1]),
                                         cal.get_nombre_bits_avec_masque(fonction1()[2]))
        fen = CTkToplevel()
        fen.geometry("1000x600+5+5")
        cal.show_table(fen, values=values,masque_final=fonction1()[2],nombre_hotes=2**(32-cal.get_nombre_bits_avec_masque(fonction1()[2])),nombres_bits_sous_reseau=n)
        fen.mainloop()
    else:
        message=""
        for i in verification[1]:
            message+=i+"\n"
        messagebox.showerror("Erreurs détectées ", message)
    pass


def affiche_sous_reseau_part2():
    verification=manage.manage_part2(fonction2()[0], fonction2()[1], fonction2()[2])
    if verification[0]:
        masque_initial=manage.get_nombre_bits_avec_masque(fonction2()[1])
        masque_final = manage.gerer_nombre_hotes(fonction2()[1], fonction2()[2])[1]
        values = cal.get_list_sous_reseau(fonction2()[0], int(masque_initial),int(masque_final))
        fen = CTkToplevel()
        fen.geometry("1000x600+5+5")
        cal.show_table(fen, values=values,masque_final=cal.calcul_masque_avec_nbr_bits(masque_final),nombres_bits_sous_reseau=(masque_final-masque_initial),nombre_hotes=2**(32-masque_final))
        fen.mainloop()
    else:
        message = ""
        for i in verification[1]:
            message += i + "\n"
        messagebox.showerror("Erreurs détectées ", message)
        pass


def show_default_masque(entry):
    ip = entry_ip_address1.get()
    if manage.gerer_adresse_ip(ip):
        if entry==entry_masque_intial:
            if entry.get()=="":
                defaut_masque.set(cal.get_genique_masque(ip))
                entry.configure(textvariable=defaut_masque)
            else:
                pass
        elif entry==entry_masque_final:
            if entry.get()=="":
                defaut_masque_final.set(cal.get_genique_masque(ip))
                entry.configure(textvariable=defaut_masque_final)
            else:
                pass
        else:
           pass
    elif manage.gerer_adresse_ip(entry_ip_address2.get()):
        defaut_masque_initial2.set(cal.get_genique_masque(entry_ip_address2.get()))
        if entry.get()=="":
            entry.configure(textvariable=defaut_masque_initial2)
        pass



    else:
        pass

def set_default_masque():
    if manage.gerer_adresse_ip(entry_ip_address2.get()) and entry_nombre_bits.get() == "":
        show_default_masque(entry_nombre_bits)
    if manage.gerer_adresse_ip(entry_ip_address1.get()):
        if entry_masque_intial.get() != "" and entry_masque_final.get() != "":
            pass
        else:
            for i in [entry_masque_intial,entry_masque_final]:
                if i.get()=="":
                    show_default_masque(i)
                pass
    pass
    root.after(100, set_default_masque)


def vlsm():
    interface_vlsm.vlsm()

root.after(100,set_default_masque)
defaut_masque=StringVar(root)
defaut_masque_final=StringVar(root)
defaut_masque_initial2=StringVar(root)
ip_label = CTkLabel(root, text="IP:", font=("Helvetica", 16)).place(x=15, y=40)

entry_ip_address1 = CTkEntry(root, width=160, font=("Helvetica", 15), corner_radius=40, placeholder_text="adresse ip")
entry_ip_address1.place(x=40, y=40)

entry_masque_intial = CTkEntry(root,width=160,font=("Helvetica", 15), corner_radius=40,
                               placeholder_text="Masque initial")
entry_masque_intial.place(x=230, y=40)
######################
entry_masque_final = CTkEntry(root, width=160, font=("Helvetica", 15), corner_radius=40,
                              placeholder_text="Masque final")
entry_masque_final.place(x=420, y=40)
#############################
ip_label2 = CTkLabel(root, text="IP:", font=("Helvetica", 16)).place(x=15, y=220)

entry_ip_address2 = CTkEntry(root, width=160, font=("Helvetica", 15), corner_radius=40, placeholder_text="adresse ip")
entry_ip_address2.place(x=40, y=220)
###################################
entry_nombre_hotes = CTkEntry(root, width=140, font=("Helvetica", 15), corner_radius=40,
                               placeholder_text="Nombre d'hôtes")
entry_nombre_hotes.place(x=430, y=220)
#######################
#label_nombre_bit_masque=CTkLabel(root,text="/ du masque:",font=("Helvetica", 19 )).place(x=280,y=220)
entry_nombre_bits = CTkEntry(root, width=190, font=("Helvetica", 15), corner_radius=40,
                             placeholder_text="Masque initial")
entry_nombre_bits.place(x=220, y=220)
#or_label=CTkLabel(root,text="OU",font=("Helvetica", 19 )).place(x=300,y=200)

show_sub_net_button = CTkButton(root, text="Afficher les résultats", corner_radius=40, height=40,
                                command=affiche_sous_reseau_part1, font=("Helvetica", 15))
show_sub_net_button.place(x=220, y=100)

show_all_info_button = CTkButton(root, text="Afficher les résultats", corner_radius=40, height=40,
                                 command=affiche_sous_reseau_part2, font=("Helvetica", 15))
show_all_info_button.place(x=240, y=280)

show_all_info_button = CTkButton(root, text="Options Avancées avec VLSM", corner_radius=40, height=35,
                                 command=vlsm, font=("Helvetica", 17))
show_all_info_button.place(x=300, y=490)

change_theme_color(root,x=5,y=500)
root.mainloop()
