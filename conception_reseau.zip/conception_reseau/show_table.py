from customtkinter import *
from tkinter import ttk
def show_tables(columns:list,values:list):
    root = CTk()
    root.title("                Voici les données de la table      ")
    set_appearance_mode("light")
    set_default_color_theme("dark-blue")
    root.geometry("600x500")
    table=ttk.Treeview(root,columns=columns,show="headings",height=200,)
    style = ttk.Style()
    style.configure("Treeview.Heading", font=("Helvetica",25,"bold"))  # Set the heading font
    style.configure("Treeview", font="Helvetica 15 bold")  # Set the font here
    for col in columns:
        table.heading(col,text=col)
    table.pack(fill=BOTH,expand=True)
    for i in values:
        table.insert(parent="",index="end",values=i)
    table.column("Réseau N°",width=150)
    root.mainloop()

#show_tables(["Réseau N°","adresse Réseau","masque sous réseau"],[(1,"192.168.39.2")])
