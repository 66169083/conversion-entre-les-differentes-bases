import math

from conversions_ import conversion_start_base_number_end_base as f
import ipaddress
from customtkinter import *
from tkinter import *
from tkinter import ttk,messagebox
from change_theme_color import change_theme_color


def get_nombre_bits_avec_masque(masque: str):
    list_octet_masque = masque.split('.', 4)
    list_bits_a_1 = ""
    for i in list_octet_masque:
        list_bits_a_1 += str(f(10, int(i), 2))
    resultat = len(list_bits_a_1.split("0")[0])
    return int(resultat)
def ETlogique(octet1, octet2):
    list_bits_oct1, list_bits_oct2, resultat = [], [], ""
    while len(octet1) != 8:
        octet1 = "0" + octet1
    while len(octet2) != 8:
        octet2 = "0" + octet2
    for i in range(8):
        list_bits_oct2.append(octet2[i])
        list_bits_oct1.append(octet1[i])
    for i in range(8):
        resultat += str(int(list_bits_oct1[i]) * int(list_bits_oct2[i]))
    return resultat
def gerer_netwok_number(taille_elements,number:str):
    resultat=False
    try:
        if not number.isdigit():
            raise ValueError
        if not 1<=int(number)<=int(taille_elements):
            raise
        number=int(number)
        resultat=True
    except:
        pass
    return  resultat


def find_network_class(ip_address: str):
    classe = ""
    list_octet_ip_address = ip_address.split(".", 4)
    if 1 <= int(list_octet_ip_address[0]) < 128:
        classe = "A"
    elif 128 <= int(list_octet_ip_address[0]) < 191:
        classe = "B"
    elif 191 <= int(list_octet_ip_address[0]) < 223:
        classe = "C"
    else:
        pass
    return classe
def get_genique_masque(ip_address):
    masque = ""
    network_class = find_network_class(ip_address)
    if network_class == "A":
        masque = "255.0.0.0"
    elif network_class == "B":
        masque = "255.255.0.0"
    elif network_class == "C":
        masque = "255.255.255.0"
    else:
        pass
    return masque
def calcul_masque_avec_nbr_bits(nombre_de_bits: int):
    nombre_octet, nombre_de_bit, nombre_octet_value, list_zero, nombre_de_bits_restant = nombre_de_bits // 8, nombre_de_bits % 8, "", [
        "0", "0", "0"], ""
    for i in range(nombre_octet):
        nombre_octet_value += "255."
    for i in range(nombre_de_bit):
        nombre_de_bits_restant += "1"
    for i in range(8 - nombre_de_bit):
        nombre_de_bits_restant = str(nombre_de_bits_restant) + "0"
    masque = str(nombre_octet_value) + str(f(2, int(nombre_de_bits_restant), 10))
    for i in range(3 - nombre_octet):
        masque += ".0"
    return masque
def get_list_sous_reseau(ip, initial_masque, final_masque):
    network = ipaddress.IPv4Network(f"{ip}/{initial_masque}", strict=False)
    subnets = network.subnets(new_prefix=final_masque)
    lists = []
    for j, i in enumerate(subnets):
        first_address = i.network_address + 1
        last_address = i.broadcast_address - 1
        brodcast = i.broadcast_address
        i, first_address, last_address = str(i), str(first_address), str(last_address)
        lists.append((j + 1, i, first_address + "/" + str(final_masque), last_address + "/" + str(final_masque),
                      str(brodcast) + "/" + str(final_masque)))
    return lists
def show_table(root, values,masque_final,nombres_bits_sous_reseau,nombre_hotes):
    root.geometry("1000x600+5+5")
    style = ttk.Style()
    style.configure("Treeview.Heading", font="Helvetica 18 bold")
    style.configure("mystyle.Treeview", font="Helvetica 20", rowheight=40)
    colums = ["N°", "masque sous réseau", "adresse première hôte", "adresse dernière hôte", "broadcast"]
    frame = CTkFrame(root, height=200)
    frame.pack(fill="x")
    table = ttk.Treeview(frame, columns=colums, show="headings", style="mystyle.Treeview", height=13)
    scrobar = Scrollbar(frame, orient="vertical", command=table.yview)
    for i in colums:
        table.heading(i, text=i)
    table.configure(yscrollcommand=scrobar.set)
    scrobar.pack(fill="y", side="right")
    table.pack(fill="x")
    for j,i in enumerate(values):
        table.insert(parent="",index=j,id=j+1,values=i)
    table.column("N°",width=70)

    def more_info_window():
        window = CTk()
        window.title("informations supplementaires")
        window.geometry("500x350+10+10")

        label_nombre_hotes_sr = CTkLabel(window, text="Nombre d'hôtes par sous réseau :", font=("Helvetica", 22))
        label_nombre_hotes_sr.place(x=20, y=10)
        resultat1=CTkLabel(window,font=("Helvetica",26,"bold"),text=nombre_hotes).place(x=370,y=10)

        label_nombre_bit_sr = CTkLabel(window, text="Nombre de bits de sous-réseau :", font=("Helvetica", 22))
        label_nombre_bit_sr.place(x=10, y=80)
        resultat2 = CTkLabel(window, font=("Helvetica", 29, "bold"), text=str(nombres_bits_sous_reseau)).place(x=370, y=80)

        label_nombre_sr = CTkLabel(window, text="Nombre sous-réseau :", font=("Helvetica", 22))
        label_nombre_sr.place(x=100, y=150)
        resultat3= CTkLabel(window, font=("Helvetica", 28, "bold"), text=str(len(values))).place(x=345, y=150)

        label_nombre_bits_hotes_sr = CTkLabel(window, text="Nombre de bits d’hôte par sous-réseau :",font=("Helvetica", 22))
        label_nombre_bits_hotes_sr.place(x=0, y=210)
        resultat4 = CTkLabel(window, font=("Helvetica", 28, "bold"), text=str(math.ceil(math.log2(nombre_hotes)))).place(x=415, y=210)

        label_masque_sr = CTkLabel(window, text="Le masque du sous réseau :", font=("Helvetica", 22))
        label_masque_sr.place(x=0, y=270)

        resultat5 = CTkLabel(window, font=("Helvetica", 26, "bold"), text=masque_final).place(x=288, y=270)

        window.mainloop()


    def search_net_work():
        network_number = search_network_entry.get()
        if gerer_netwok_number(len(values),network_number):
            table.selection_set([network_number])
            table.see(network_number)
        else:
            messagebox.showerror("Numéro du réseau est incorrect","nombre incorrect")
    search_network_entry = CTkEntry(root, corner_radius=40, width=200, height=37,
                                    placeholder_text="exemple 5", font=("Helvetica", 18))
    search_network_entry.place(x=660, y=460)
    label = CTkLabel(root, text="Entrer le numéro sous réseau ici:", font=("helvetica", 23), corner_radius=10).place(
        x=280, y=464)
    search_network_button = CTkButton(root, command=search_net_work, text="Chercher le réseau", width=100, height=50,
                                      font=("Helvetica", 15), corner_radius=30)
    search_network_button.place(x=800, y=510)

    info_supp_button=CTkButton(root,command=more_info_window,text="Plus d'informations",corner_radius=30,font=("Helvetica",18),
    width=180,height=46)
    info_supp_button.place(x=20,y=450)
    change_theme_color(root, x=5, y=550)
    root.mainloop()
root=CTk()
value=[]
for i in range(15):
    value.append(("1","bonjour","tout","le monde"))
#show_table(root,value,"","","")
