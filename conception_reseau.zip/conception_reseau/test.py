import customtkinter as ct
from database.logique import insert_values as ins

root = ct.CTk()
ct.set_appearance_mode("light")
root.geometry("600x600")
ct.set_default_color_theme("green")


def save():
    nom = entry_name.get()
    prenom = entry_surname.get()
    identite = entry_id.get()
    ins(identite, nom, prenom)
    label1.configure(text="enregistrer avec succès")


label = ct.CTkLabel(root, text="Entrer votre identifiant:", )
label.place(x=100, y=60)
label = ct.CTkLabel(root, text="Entrer votre nom:", )
label.place(x=100, y=120)
label = ct.CTkLabel(root, text="Entrer votre prenom", )
label.place(x=100, y=180)
entry_name = ct.CTkEntry(root, corner_radius=50, show="*", placeholder_text="entrer votre nom", font=("Helvetica ", 15))
entry_name.place(x=250, y=120)
entry_id = ct.CTkEntry(root, corner_radius=50, placeholder_text="id")
entry_id.place(x=250, y=60)
entry_surname = ct.CTkEntry(root, corner_radius=50, placeholder_text="Prenom")
entry_surname.place(x=250, y=180)
save_button = ct.CTkButton(root, text="Enregistrer les données", corner_radius=50, command=save, height=50)
save_button.place(x=220, y=300)
label1 = ct.CTkLabel(root, text="", font=("Helvetica", 15))
label1.place(x=220, y=350)

table = ct.CTkTabview(root, width=150, height=150, corner_radius=50, segmented_button_unselected_color="white", )
table.place(x=320, y=380)
root.mainloop()
