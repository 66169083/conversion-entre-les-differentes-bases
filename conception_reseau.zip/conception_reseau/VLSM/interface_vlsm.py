from customtkinter import  *
from tkinter import  ttk,messagebox
from tkinter import *
def vlsm():
    root=CTk()
    root.geometry("620x560+650+5")


    def get_network_number():
        j = 0
        for i in range(5):
            label = CTkLabel(frame, text="Entrer le nombre d'hôtes du réseau " + str(i + 1) + ":",font=("Helvetica", 19, "bold")).place(relx=0.05,rely=0.22 + j)
            i = CTkEntry(frame, corner_radius=30, placeholder_text="Réseau N°" + str(i + 1), width=110, height=40)
            i.place(relx=0.62, rely=0.208 + j)
            j += 0.1

    network_number_entry=CTkEntry(root,corner_radius=30,placeholder_text="Entrer le nombre de réseau")
    network_number_entry.place(x=260,y=30)
    label=CTkLabel(root,text="Entrer le nombre de réseau:",font=("Helvetica",19)).place(x=10,y=30)
    entry_button=CTkButton(root,text="Entrer",corner_radius=30,command=get_network_number)
    entry_button.place(x=290,y=80)
    ####################
    frame=CTkScrollableFrame(root,width=600,height=300)
    frame.place(relx=0,rely=0.19)
    entry_ip_address1 = CTkEntry(root, width=180, height=40,font=("Helvetica", 15), corner_radius=40, placeholder_text="adresse ip")
    entry_ip_address1.place(x=40, y=450)

    masque_initial = CTkEntry(root, width=170, height=40,font=("Helvetica", 15), corner_radius=40, placeholder_text="masque initial")
    masque_initial.place(x=400, y=450)

    valider_button=CTkButton(root,text="voir les résultats",width=150,height=45,corner_radius=30,command=get_network_number)
    valider_button.place(x=250,y=500)



    lab=CTkEntry(frame,bg_color="red").place(x=250,y=250)



    root.mainloop()
