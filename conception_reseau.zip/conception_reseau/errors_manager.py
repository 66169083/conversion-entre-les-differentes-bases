from math import log2,ceil
from conversions_ import  conversion_start_base_number_end_base as f



def gerer_adresse_ip(ip_address: str):
    resultat = False
    try:
        nombre_ponit, index_point = 0, []
        for j, i in enumerate(ip_address):
            if i == ".":
                index_point.append(j)
                nombre_ponit += 1
        for i in index_point:
            if not ip_address[i + 1].isdigit():
                raise ValueError
        if nombre_ponit != 3:
            raise ValueError
        octet_ip = ip_address.split(".", 4)
        for i in octet_ip:
            if not i.isdigit():
                raise ValueError
            if int(i) > 254:
                raise ValueError
            if int(octet_ip[0]) >= 224 or int(octet_ip[0]) < 1 or (len(i)>=3 and int(i)<100) or (len(i)>=2 and int(i)<10) or i=="00":
                raise ValueError
        resultat = True
    except:
        pass
    return resultat
def get_nombre_bits_avec_masque(masque: str):
    list_octet_masque = masque.split('.', 4)
    list_bits_a_1 = ""
    for i in list_octet_masque:
        list_bits_a_1 += str(f(10, int(i), 2))
    resultat = len(list_bits_a_1.split("0")[0])
    return int(resultat)


def gerer_netwok_number(taille_elements,number:str):
    resultat=False
    try:
        if not number.isdigit():
            raise ValueError
        if not 1<=int(number)<=int(taille_elements):
            raise
        number=int(number)
        resultat=True
    except:
        pass
    return  resultat

def manage_masque(masque: str):
    resultat = False
    try:
        list_oct_masque, nombre_point, nombre_225 = masque.split(".", 4), 0, []
        for i in masque:
            if i == ".":
                nombre_point += 1
        if nombre_point != 3:
            raise ValueError
        authorise_octetl_list = [0, 128, 192, 224, 240, 248, 252, 254, 255]
        for j, i in enumerate(list_oct_masque):
            if len(i)>=2 and int(i)<10 or len(i)>=3 and int(i)<100:
                raise ValueError
            i = int(i)
            if not int(i) in authorise_octetl_list:
                raise ValueError
            if int(i) > 255 and int(i) < 1:
                raise ValueError
            if int(i) == 255:
                nombre_225.append(j)
        for i in range(nombre_225[-1]):
            if int(list_oct_masque[i]) != 255:
                raise ValueError
        resultat = True
    except:
        pass
    return resultat


def nombre_bit_masque(nombre_bits: str):
    resultat = False
    try:
        if not nombre_bits.isdigit():
            raise ValueError
        if int(nombre_bits) > 31 or int(nombre_bits) < 1:
            raise ValueError
        nombre_bits = int(nombre_bits)
        resultat = True
    except:
        pass
    return resultat


def gerer_masque_init_final(masque_initial: str, masque_final: str):
    resultat = False
    list_error = []
    try:
        masque_final_octet = masque_final.split(".", 4)
        masque_initial_octet = masque_initial.split(".", 4)
        diff_octet = []
        for i in range(4):
            diff_octet.append(int(masque_final_octet[i]) - int(masque_initial_octet[i]))
        for i in diff_octet:
            if i < 0:
                raise ValueError

        resultat = True
    except:
        pass
    return resultat


def manage_part1(ip_address, masque_initial, masque_final):
    list_erros = []
    if not gerer_adresse_ip(ip_address):
        list_erros.append("addresse ip incorrect")
    if not manage_masque(masque_initial):
        list_erros.append("masque initial incorrect")
    if not manage_masque(masque_final):
        list_erros.append("masque final incorrect")
    if (manage_masque(masque_initial) and manage_masque(masque_final)) and not gerer_masque_init_final(masque_initial,masque_final):
        list_erros.append("masque  final doit être > masque initial incorrect")
    if gerer_adresse_ip(ip_address) and manage_masque(masque_initial) and manage_masque(
            masque_final) and gerer_masque_init_final(masque_initial, masque_final):
        return True, list_erros
    return False, list_erros


def gerer_nombre_hotes(masque_initial: str, nombre_hotes:str):
    n=0
    resultat = False
    try:
        if not nombre_hotes.isdigit():
            raise ValueError
        nombre_hotes = int(nombre_hotes)
        nombre_hote = 2 ** (32 - int(get_nombre_bits_avec_masque(masque_initial)))
        if int(nombre_hotes) > nombre_hote:
            raise ValueError
        if (int(nombre_hotes)<0):
            raise ValueError
        n=ceil(log2(int(nombre_hotes)+2))
        n=32-n
        if n<int(get_nombre_bits_avec_masque(masque_initial)):
            raise ValueError
        resultat = True
    except:
        pass
    return resultat,n
def manage_part2(ip_address, masque, nombre_hotes):
    resultat, erros_list = False, []
    try:
        n=(gerer_nombre_hotes(masque,nombre_hotes)[1]-get_nombre_bits_avec_masque(masque))
    except:
        pass
    if not gerer_adresse_ip(ip_address):
        erros_list.append("adresse ip incorrect")
    if not gerer_nombre_hotes(masque,nombre_hotes)[0]:
        erros_list.append("nombre hotes invalide")
    if not manage_masque(masque):
        erros_list.append("masque invalide")
    if gerer_adresse_ip(ip_address) and gerer_nombre_hotes(masque,nombre_hotes)[0] and manage_masque(masque):
        resultat = True
    return resultat, erros_list