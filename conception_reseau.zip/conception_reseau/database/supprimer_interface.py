from customtkinter import *
from sqlite3 import *
from logique import supprimer_data,get_tables_list,get_table_colums,check_primary_key_var

def supprimer(database):
    root = CTk()
    root.geometry("600x600")
    def get_entry():
        entry=primary_attribut_entry.get()
        return entry

    def pack_():
        primary_attribut_entry.place(x=250, y=100)
        button.place(x=100, y=200)
        attribut_label = CTkLabel(root, text="Entrer " + ":", font=("Helvetica", 22, "bold")).place(x=10, y=100)
        label.configure(text=get_entry())

    def entry():
        return primary_attribut_entry.get()



    def fonction_supprimer(*args):
        table_name = combobox.get()
        if check_primary_key_var(database,table_name):
            print(pack_())
            print(entry())






        print("fin")
        """if get_table_name()[1]:
            primary_attribut=get_table_name()[1]
            
            key_value=primary_attribut_entry.get()
            print(key_value)
            if key_value:
                supprimer_data(database,get_table_name([0]),key_value)"""

    combobox=CTkComboBox(root,width=320,command=fonction_supprimer,state="readonly",values=get_tables_list(database),height=55,font=("Helvetica",20,"bold"),dropdown_font=("helvetica",21,"bold"))
    combobox.pack()
    combobox.set("Selectionner une table")
    label=CTkLabel(root,text="ok")
    label.place(x=50,y=300)
    primary_attribut_entry = CTkEntry(root, corner_radius=40, placeholder_text="Entrer ", font=("Helvetica", 16),width=100 + 2)
    button = CTkButton(root, text="Supprimer", command=get_entry)
    a=button.bind("<<Button-1>>", entry)
    print(a)
    print(entry())
    root.mainloop()
supprimer("donne.db")