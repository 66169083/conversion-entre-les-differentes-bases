from customtkinter import *
from sqlite3 import *
from tkinter import *
from logique import get_table_colums, get_tables_list, insert_values

root = CTk()
root.geometry('600x600+10+10')


def insert_value(database):

    def pack_entry(*args):
        colums_list=afficher_entry()
        list=[]
        for j,i in enumerate(colums_list):
            i = CTkEntry(frame, corner_radius=40, placeholder_text=(str(i)), height=32, font=("Helvetica", 16),
                         width=100 + 20 * len(i))
            i.pack(pady=10)
            list.append(i)
        frame.place(x=5, y=70)


    def afficher_entry(*args):
        table_name = combobox.get()
        colums_list = get_table_colums(database, table_name)


        """for i in pack_entry(colums_list):
            i.destroy()
        
        pack_entry(colums_list)"""

        return colums_list
    combobox = CTkComboBox(root, command=pack_entry, values=get_tables_list(database), width=320, state="readonly",
                           height=55, font=("Helvetica", 20, "bold"), dropdown_font=("helvetica", 21, "bold"))
    combobox.pack()
    combobox.set("Selectionner une table")

    def inserer(*args):
        pass

    frame = CTkScrollableFrame(root, border_width=1, bg_color="gray92", width=570, height=400, )
    insert_button = CTkButton(root, text="Inserer les données", width=100, height=60, font=("Helvetica", 18, "bold"))
    insert_button.place(x=300, y=500)
    root.mainloop()


insert_value("donne.db")
