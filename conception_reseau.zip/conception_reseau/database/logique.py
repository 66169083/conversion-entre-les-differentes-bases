import sqlite3 as sq
from database.show_table import show_tables
from sqlite3 import *
from tkinter import ttk
from customtkinter import *


def insert_values(database_name, table_name, values):
    data = sq.connect("donne.db")
    datas = (data.execute(f'''PRAGMA table_info({table_name})''')).fetchall()
    columns = []
    for i in range(len(datas)):
        columns.append(datas[i][1])
    print(columns)

    data.commit()
    data.close()


#insert_values("donne.db", "ETUDIANT", "")


def show_values():
    data = sq.connect("donne.db")
    datas = data.execute("SELECT * FROM ETUDIANT")
    list_values = datas.fetchmany(70)
    cursor = data.cursor()
    colums = (cursor.execute('''PRAGMA table_info(ETUDIANT)''')).fetchall()
    nombre_colonnes = len((colums))
    colum_list = []
    print(colums)
    for i in range(nombre_colonnes):
        colum_list.append(colums[i][1])
    data.close()
    return list_values
def get_table_colums(database,table_name):
    data=connect(database)
    cursor=data.cursor()
    colums=(cursor.execute(f'''PRAGMA table_info({table_name})''')).fetchall()
    resultat=[]
    for i in range(len(colums)):
        resultat.append(colums[i][1])
    return  resultat
def get_tables_list(database):
    data = connect(database)
    cursor = data.cursor()
    col = []
    tables_name = (cursor.execute('''SELECT name FROM sqlite_master WHERE type="table";''')).fetchall()

    for i in tables_name:
        col.append(i[0])
    resultat = col
    data.close()
    return resultat

def essai(database: str, table_name=""):
    try:
        data = sq.connect(database)
        cursor = data.cursor()
        col = []
        tables_name = (cursor.execute('''SELECT name FROM sqlite_master WHERE type="table";''')).fetchall()
        for i in tables_name:
            col.append(i[0])
        if table_name != "" and table_name in col:
            col = [table_name]
        for table_name in col:
            colums_list = []
            colums = (cursor.execute(f'''PRAGMA table_info({table_name})''')).fetchall()
            datas = (cursor.execute(f'''SELECT * FROM {table_name}''')).fetchmany(50000)
            for i in range(len(colums)):
                colums_list.append(colums[i][1])
            show_tables(table_name, colums_list, datas)
        data.close()
    except:
        pass
def check_primary_key_var(database, table_name):

    data = connect(database)
    cursor = data.cursor()
    colums_datas = (cursor.execute(f'''PRAGMA table_info({table_name})''')).fetchall()
    primary_attribut = ""
    for i in range(len(colums_datas)):
        if colums_datas[i][5] == 1:
            primary_attribut = colums_datas[i][1]
    data.close()
    return primary_attribut

def supprimer_data(database, table_name, primary_key):
    data = connect(database)
    cursor = data.cursor()
    cursor.execute(
        f'''delete from {table_name} WHERE {check_primary_key_var(database, table_name)}={primary_key}''')
    data.commit()
    data.close()

def show_table(database: str, table_name=""):
    status = ""
    try:
        data = sq.connect(database)
        cursor = data.cursor()
        col = []
        tables_name = (cursor.execute('''SELECT name FROM sqlite_master WHERE type="table";''')).fetchall()

        for i in tables_name:
            col.append(i[0])
        if table_name in col:
            col = [table_name]
        for table_name in col:
            colums_list = []
            colums = (cursor.execute(f'''PRAGMA table_info({table_name})''')).fetchall()
            datas = (cursor.execute(f'''SELECT * FROM {table_name}''')).fetchmany(50000)
            for i in range(len(colums)):
                colums_list.append(colums[i][1])
            emptytreeview_table(table_name, colums_list, datas)
            status = "ok"
        data.close()
    except:
        pass
    return status
def emptytreeview_table(table_name, columns: list, values: list):
    root = CTk()
    root.title("Voici les données de la table      " + table_name)
    set_appearance_mode("light")
    set_default_color_theme("dark-blue")
    root.geometry("600x500")

    table = ttk.Treeview(root, columns=columns, show="headings", height=200)
    style = ttk.Style()
    style.configure("Treeview.Heading", font="Arrial 19 bold")
    style.configure("Treeview", font=("Helvetica", 15, "bold"), bg="red")
    for col in columns:
        table.heading(col, text=col)
    table.pack(fill=BOTH, expand=True)
    for i in values:
        table.insert(parent="", index="end", values=i)
    root.mainloop()

