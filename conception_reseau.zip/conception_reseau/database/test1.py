import phonenumbers
from phonenumbers import geocoder,carrier
import folium
from opencage.geocoder import OpenCageGeocode
number="+22666052007"
phone=phonenumbers.parse(number)
#print(geocoder.description_for_number(phone,"en"),carrier.name_for_valid_number(phone,"en"))
key="617fc0a50b2f47da92f3f9200255aa6c"
location=geocoder.description_for_number(phone,"en")
geocoder=OpenCageGeocode(key)
query=str(location)
resultat=geocoder.geocode(query)
print(resultat)
lat=resultat[0]["geometry"]["lat"]
lng=resultat[0]["geometry"]["lng"]
print(lat,lng)
map=folium.Map(location=[lat,lng],zoom_start=9)
folium.Marker([lat,lng],popup=location).add_to(map)
map.save("output.html")