from sqlite3 import *
def check_primary_kek_var(database,table_name):
    data = connect(database)
    cursor = data.cursor()
    colums_datas= (cursor.execute(f'''PRAGMA table_info({table_name})''')).fetchall()
    primary_attribut = ""
    for i in range(len(colums_datas)):
        if colums_datas[i][5] == 1:
            primary_attribut = colums_datas[i][1]
    data.close()
    return primary_attribut
#print(check_primary_kek_var("donne.db","ENFANT"))
def supprimer(database,table_name,primary_key):
    data=connect(database)
    cursor =data.cursor()
    cursor.execute(f'''delete from {table_name} WHERE {check_primary_kek_var(database,table_name)}={primary_key}''')
    data.commit()
    data.close()

print(supprimer("donne.db","EMPLOYE",100))
dat=connect("donne.db")
dat.execute('''INSERT INTO EMPLOYE(Id,Nom ,Prenom, Salaire)
VALUES(1000,"Zida","JEAN",50000)
''')
dat.commit()
dat.close()