from customtkinter import *
import interface_afficher
from database.get_path import simplify_path
root=CTk()
root.geometry("600x400")
set_default_color_theme("green")
def get_database_path():
    path=filedialog.askopenfilename(filetypes=[("fichiers",".db")])
    label.configure(text=str(path))
def afficher():
    database=label.cget("text")
    interface_afficher.view_data(simplify_path(database))
    print(database)
def modifier():
    pass
def supprimer():
    pass
def inserer():
    pass

bd_button=CTkButton(root,command=get_database_path,text="Selectionner la base de donnée",font=("Helvetica",17),height=40)
bd_button.place(x=30,y=50)

inserer_button=CTkButton(root,text="Insérer",font=("Helvetica",17),height=50,command=inserer)
inserer_button.place(x=30,y=150)

modifier_button=CTkButton(root,text="Modifier",font=("Helvetica",17),height=50,command=modifier)
modifier_button.place(x=230,y=150)

supprimer_button=CTkButton(root,text="Supprimer",font=("Helvetica",17),height=50,command=supprimer)
supprimer_button.place(x=430,y=150)

consulter_button=CTkButton(root,text="Consulter les données",height=55,font=("Helvetica",17),command=afficher)
consulter_button.place(x=200,y=300)
label=CTkLabel(root,text="")
label.pack()



root.mainloop()