from customtkinter import *
from logique import get_tables_list,show_table


def view_data(database):
    root = CTk()
    root.geometry("540x400")
    set_appearance_mode("light")
    set_default_color_theme("green")

    def fonction(*args):
        table_name=combobox.get()
        print(table_name)
        show_table(database,table_name)
    combobox = CTkComboBox(root,state="readonly", width=350,command=fonction,values=get_tables_list(database), height=60,font=("helvetica", 22, "bold"), dropdown_font=("Helvetica", 20, "bold"))
    combobox.place(x=80, y=20)
    combobox.set("Selectionner une table")
    root.mainloop()
view_data("donne.db")