def simplify_path(path):
    symbol_position,number_symbols=[],0
    for j,i in enumerate(path):
        if i=="/":
            symbol_position.append(j)
            number_symbols+=1
    path=path[symbol_position[-1]+1:]
    return path