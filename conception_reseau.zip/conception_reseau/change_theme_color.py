from customtkinter import *
def change_theme_color(root,x,y):
    def set(*args):
        set_appearance_mode(button.get())
    label=CTkLabel(root,text="Mode Sombre",font=("Helvetica",14)).place(x=x,y=y)
    button=CTkSwitch(root,text="",hover=False,corner_radius=20,command=set,onvalue="dark",offvalue="light")
    button.place(x=x+100,y=y+5)
    root.mainloop()