from _decimal import *

def decimal_part_conversion(start_base, decimal_part, end_base):
    codage, result1, a, v, result, t1 = [], "", str(decimal_part), [], 0, []
    T, t = [], [f"{i}" for i in range(10)] + ["A", "B", "C", "D", "E", "F"]
    d2, d1 = {f"{t[i]}": f"{i}" for i in range(16)}, {f"{i}": f"{t[i]}" for i in range(16)}
    d2.update(d1)
    for i in a:
        T.append(i)
    for i in T:
        v.append(d2[i])
    if len(v) <= 10:
        pass
    else:
        for i in range(10,len(v)):
            v[i]="0"
    for i, j in enumerate(v):
        result += int(j) * start_base ** (-(i + 1))
    while len(codage) < 15:
        result *= end_base
        codage.append(str(int(result)))
        result -=int(result)
    for i in codage:
        t1.append(d2[i])
    t1 = t1[::-1]
    i = 0
    while t1[i] == "0" and i < len(t1) - 1:
        t1.remove(t1[i])
        i += i
    t1 = t1[::-1]
    for j in t1:
        result1 += j
    return result1
