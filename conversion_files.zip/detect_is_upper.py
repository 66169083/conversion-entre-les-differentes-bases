import string


def is_upper(carctere:str):
    a,t=string.ascii_uppercase,[]
    for i in a:
        t.append(i)
    for i,j in enumerate(t):
        if carctere.isupper and i<15:
            return 5
print(is_upper("u"))