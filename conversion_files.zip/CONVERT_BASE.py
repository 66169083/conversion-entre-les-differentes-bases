def convert_base(number, base):
    t, T, result = [], [], ""
    a, b = int(number), base
    while a != 0:
        T.append(a % b)
        a //= b
    T = T[::-1]
    for i in T:
        t.append(str(i))
    for j in t:
        result += j
    return [result, t]
