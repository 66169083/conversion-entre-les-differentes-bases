from conversions import conversion_start_base_number_end_base as f1
from decodage_codage_BCD_GRAY import *


def decodage_codage(start_base, number, end_base):
    # Base : 1 =GRAY, Base : -2 =BCD

    a, b, c = start_base, number, end_base
    if a != 1 and c != -2 and a != -2 and c != 1:
       return f1(start_base,number,end_base)
    else:
        if a == 1:
            return decodage_gray(number,end_base)
        elif c == 1:
            return codage_gray(b, a)
        elif a == -2:
            return decodage_BCD(b, c)
        elif c == -2:
            return codage_BCD(b, a)
