import qrcode as qr
a=input("entrer l'expression a convertir en qrcode :")
b=input("entrer le nom du fichier que vous aller creer:")
im=qr.make(a)
im.save(b+".jpg")

