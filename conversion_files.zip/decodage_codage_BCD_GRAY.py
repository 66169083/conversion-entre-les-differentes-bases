from conversions import conversion_start_base_number_end_base as funct2

t, T, ch, s = [], [], '', ""
def decodage_gray(number, end_base):
    c = str(number)
    c = c[::-1]
    t, T, s, indexes= [], [], 0, []
    for i in c:
        T.append(int(i))
    for i in range(len(T)):
        if T[i] == 1:
            t.append(1)
            indexes.append(i)
    T = []
    for i in indexes:
        T.append(i + 1)
    T = T[::-1]
    for i, j in enumerate(t):
        s += (-1) ** (i) * (2 ** (T[i]) - 1)
    return funct2(10, s, end_base)
###########################################
def codage_gray(number, base):
    number= funct2(base, number, 2)
    t, T, v, result, a = [], [], [], "", str(a)
    for i in a:
        t.append(int(i))
    T = t
    T = [0] + T
    t = t + [0]
    for i in range(len(t)):
        v.append(str(T[i] + t[i]))
    v = v[0:len(v) - 1]
    for i in range(len(v)):
        if v[i] == '2':
            v[i] = '0'
    for i in v:
        result += i
    return result
###############################################
def codage_BCD(number, start_base):
    a, result= str(number), ""
    for i in a:
        t.append(str(funct2(start_base, i, 2)))
    for i in t:
        while len(i) < 4:
            i = "0" + i
        T.append(i)
    for i in T:
        result += i
    return result


####################################################
# decodage BCD

def decodage_BCD(number, base):
    a, b, s = str(number), int(base), ""
    codage_gray_number=codage_gray(number, base)
    decodage_gray_number=decodage_gray(codage_gray_number,10)
    number=str(decodage_gray_number)
    c=len(number)
    a=number
    while c % 4 != 0:
        a = "0" + a
        c += 1
    for i in range(int(len(a) / 4)):
        t.append(a[4 * i:4 * (i + 1)])
    for i in t:
        s += str(funct2(2, int(i), b))
    return s
print(decodage_BCD(11110,10))