def codage_BCD(number,base):
    a,t,T,v,result=str(number),[],[],[],""
    for i in a:
        t.append(int(i))
    T = t
    T = [0] + T
    t = t + [0]
    for i in range(len(t)):
        v.append(str(T[i] + t[i]))
    v = v[0:len(v) - 1]
    for i in range(len(v)):
        if v[i] == '2':
            v[i] = '0'
    for i in v:
        result += i
    c = str(number)
    c = c[::-1]
    t, T, s, indexes = [], [], 0, []
    for i in c:
        T.append(int(i))
    for i in range(len(T)):
        if T[i] == 1:
            t.append(1)
            indexes.append(i)
    T = []
    for i in indexes:
        T.append(i + 1)
    T = T[::-1]
    for i, j in enumerate(t):
        s += (-1) ** (i) * (2 ** (T[i]) - 1)
    return result
print(codage_BCD(11110,10))