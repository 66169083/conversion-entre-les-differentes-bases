from Main_functions import conversion_integer_and_decimal_number as funct1
from tkinter import *
from tkinter import ttk
from erro_manager import check_error
fen=Tk()
d={"Binaire":2,"Décimal":10,"Octal":8,"Hexadécimal ":16}
list_base=list(d.keys())
t,T=[],[]
Font1="broadway 10 bold italic"
Font2="broadway 15 bold italic"
Font3="broadway 22 bold italic"
fen .geometry("1000x900")
fen.config(bg="blue")
entry_num=Entry(fen,width=40,font=Font3)
entry_num.place(x=130,y=250)
"""frame=Frame(fen, width=600,height=100,bg="white")
frame.place(x=30,y=650)"""
def combo_get(*args):
    depart_base_key=combo1.get()
    base_arrivee_key=combo2.get()
    if depart_base_key and base_arrivee_key in list_base:
        base_depart=int(d[combo1.get()])
        base_arrive =int( d[combo2.get()])
        num_to_convert = entry_num.get()
        num_to_convert =  check_error(base_depart, num_to_convert)
        #print(num_to_convert,base_arrive,base_depart)
        result = funct1(start_base=base_depart, number=num_to_convert[1], end_base=base_arrive) if num_to_convert[0] is True else f"Ces caracteres:{num_to_convert[2]} ne sont pas autorises dans la base {base_depart}"
        result_lb["text"] = "="+str(result)
        print(result)
        entry_num.after(100,combo_get)
    else:
        pass
   
combo1=ttk.Combobox(fen,values=list_base,width=25,font=Font3)
combo1.place(x=130,y=80)
combo1['state']='readonly'
combo1.set("Décimal")
combo1.bind("<<ComboboxSelected>>", combo_get)
#combobox2
combo2=ttk.Combobox(fen,values=list_base,width=20,font=Font3)
combo2.place(x=230,y=350)
combo2['state']='readonly'
combo2.set("Décimal")
combo2.bind("<<ComboboxSelected>>", combo_get)
result_lb=Label (fen, text="",font=Font3)
result_lb.place(x=80,y=500)
 
fen.mainloop()