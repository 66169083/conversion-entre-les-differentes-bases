from Main_functions import conversion_integer_and_decimal_number as function
from sign_number import sign_number as f

class Conversion:
    def __init__(self,number=0,base=10):
        self.base=base
        self.number=number
    def addition(self,number1,number2,base):
        number1=f(number1)
        number2=f(number2)
        if number2 ==100 and number1==100:
            return "error de nombre"
        else:
            number1_in_decimal=function(base,number1,10)
            number2_in_decimal=function(base,number2,10)
            return function(10,number2_in_decimal+number1_in_decimal,base)

    def soustraction(self, number1, number2, base):
        number1_in_decimal = function(base, number1, 10)
        number2_in_decimal = function(base, number2, 10)
        return function(10, number2_in_decimal - number1_in_decimal, base) if number2_in_decimal>number1_in_decimal  else  "-"+function(10, -number2_in_decimal + number1_in_decimal, base)

    def multiplication(self, number1, number2, base):
        try:
            number1_in_decimal = function(base, number1, 10)
        except:

            number1_in_decimal = function(base, number1, 10)

        number2_in_decimal = function(base, number2, 10)
        return function(10, number2_in_decimal * number1_in_decimal, base) if number2_in_decimal>=0 and number1_in_decimal>=0 else "-"+function(10, -number2_in_decimal * number1_in_decimal, base)
    def division(self,start_base,number1,number2,end_base):
        number1_in_decimal = function(start_base, number1, 10)
        number2_in_decimal = function(start_base, number2, 10)
        return function(10, number1_in_decimal / number2_in_decimal,end_base)


f=Conversion()
print(f.division(2,1111,1110,2))
print(function(2,1111/1110,2))
