# from CONVERT_BASE import convert_base as funct1
# from Main_function import decodage_codage as funct2


def check_error(base, user_entry):
    allow_chars,nombre_de_signe,nombre_de_virgule=[],0,0
    allow_chars1=[]
    for i in user_entry:
        if i=="-":
            nombre_de_signe +=1
    for i in user_entry:
        if i==".":
            nombre_de_virgule+=1
    for i in range(1,len(user_entry)):
        if nombre_de_signe <=1 and nombre_de_virgule<=1 and user_entry[0]!="." :
            allow_chars1=[".","-"]
        else:
            allow_chars1=[]
    if base == 1 or base == -2:
        allow_chars = [f"{i}" for i in range(2)]
    elif base != 16:
        allow_chars = [f"{i}" for i in range(base)]
    elif base == 16:
        allow_chars = [f"{i}" for i in range(10)] + ["A", "B", "C", "D", "E", "F"]
    else:
        pass
    incorrect_chars = ""
    correct = True
    allow_chars+= allow_chars1
    user_entry_ = user_entry
    for char in user_entry_:
        if char not in allow_chars:
            incorrect_chars += char
            correct = False
    return correct,  user_entry, incorrect_chars
print(check_error(16,"52-5"))