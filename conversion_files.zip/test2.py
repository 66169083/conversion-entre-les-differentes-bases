from random import *
t=["+","-","*"]
a=randint(1,15)
b=randint(1,15)
d=choice(t)
print(str(a)+str(d)+str(b)+"=?")
answer=input("entrer le resultat de l'operation ci-dessus:")
if d=="+":
    answer1=a+b
elif d=="-":
    answer1=a-b
elif d=="*":
    answer1=a*b
while str(answer1)!= answer:
    print(str(randint(1,10)) + str(choice(t)) + str(randint(1,10)) + "=?")
    answer = input("entrer le resultat de l'operation ci-dessus:")

