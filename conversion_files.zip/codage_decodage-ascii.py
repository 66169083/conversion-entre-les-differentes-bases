import string as st

t = [f"{i}" for i in range(10)] + ["A", "B", "C", "D","E", "F"]
d2, d1 = {f"{t[i]}": f"{i}" for i in range(16)}, {f"{i}": f"{t[i]}" for i in range(16)}
d2.update(d1)
def ascii_function(chaine):
    digit_dictionary = {f"{i}": f"{(48 + i, "3" + str(i))}" for i in range(10)}
    a,v = st.ascii_uppercase,[]
    for i in a:
        v.append(i)
    bool_upper=True
    for i in v:
        if str(i).isupper() and
    string_dictionary={f"{}"}
    print(v)


ascii_function("hello")
