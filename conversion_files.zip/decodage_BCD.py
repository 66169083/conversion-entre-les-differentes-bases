from codage_main import code_main as funct2
from Main_function1 import decodage_codage as f
def BCD_decodage(number,base):
    a,b=number,base
    a=str(a)
    c=len(a)
    t,s=[],""
    while c%4!=0:
        a="0"+a
        c+=1
    for i in range(int(len(a)/4)) :
        t.append(a[4*i:4*(i+1)])
    for i in t:
        s+=str(f(2,int(i),b))
    return s  
        