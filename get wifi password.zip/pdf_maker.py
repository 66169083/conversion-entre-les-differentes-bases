from fpdf import FPDF


pdf = FPDF("P", "mm", "Letter")

pdf.add_page()
pdf.set_font("Helvetica", "BUI", 10)
pdf.set_font("times", "", 12)
t = ["bonjour", "tout", "le monde ", "se porte bien"]
for i in t:
    pdf.multi_cell(10, 5, i)
pdf.output("file.pdf")
