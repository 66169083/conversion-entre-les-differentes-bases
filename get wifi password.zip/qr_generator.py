import qrcode
from tkinter import *
from tkinter import *
from PIL import Image
import pyqrcode




def qrcode_generator(encryption,ssid,password):
    data=f"WIFI:T:{encryption};S:{ssid};P:{password};;"
    img=qrcode.make(data)
    image=img.get_image()

    return image


a=qrcode_generator("WPA2||WPA","WIFI EPO","@Wifi@!2022EPO")
print(a)

