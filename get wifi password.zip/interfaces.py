import qrcode
from PIL import Image

def qrcode_generator(encryption, ssid, password):
    data = f"WIFI:T:{encryption};S:{ssid};P:{password};;"
    img = qrcode.make(data)
    """img.save("qrcode.png")
    image = Image.open("qrcode.png")
    image = image.resize((250, 250))
    image.save("qrcode.png")"""
    img.show()
qrcode_generator("WPA2","WIFI EPO","1234569")