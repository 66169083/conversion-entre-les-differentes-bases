import os
from tkinter import filedialog
from customtkinter import *
from threading import Thread
from time import sleep


root=CTk()
root.geometry("600x600+10+30")


def valider():
    for i in range(10):
        i=CTkFrame(frame,height=300,width=500,bg_color="red")
        i.pack(expand=True,side="top",pady=30)
        label1=CTkLabel(i,text="bonjour").place(x=50,y=50)


button=CTkButton(root,text="valider",command=valider)
frame=CTkScrollableFrame(root,width=500,height=350,)
frame.place(x=10,y=20)
label=CTkLabel(frame,text="Remplisser les cases ci_dessous").pack()
button.place(x=150,y=500)
root.mainloop()