from PyPDF2 import PdfWriter,PdfReader
def encrypt_pdf_files(pdf_file,password):
    pdf_reader=PdfReader(pdf_file)
    pdf_writer=PdfWriter()
    for page_num in range(len(pdf_reader.pages)):
        pdf_writer.add_page(pdf_reader.pages[page_num])
    pdf_writer.encrypt(password)
    with open(pdf_file,"wb") as f:
        pdf_writer.write(f)
        f.close()

def decrypt_pdf_files(pdf_file,password):
    pdf_reader=PdfReader(pdf_file)
    list_error=""
    if pdf_reader.is_encrypted:
        if pdf_reader.decrypt(password):
            pdf_writer=PdfWriter()
            for page_num in range(len(pdf_reader.pages)):
                pdf_writer.add_page(pdf_reader.pages[page_num])
            encryt_file_name=pdf_file
            with open(str(encryt_file_name),"wb") as f:
                pdf_writer.write(f)
                f.close()
        else:
            list_error="mot de passe incorect"
    else:
        list_error="le fichier n'est pas crypté"
    return list_error