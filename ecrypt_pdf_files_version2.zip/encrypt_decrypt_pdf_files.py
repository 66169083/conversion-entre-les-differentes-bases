from tkinter import filedialog, messagebox
from customtkinter import *
from logique import encrypt_pdf_files, decrypt_pdf_files
import os
from change_theme_color import  change_theme_color


root = CTk()
def get_file_path():
    path = filedialog.askopenfilename(filetypes=[("fichiers pdf", ".pdf")])
    label_path.configure(text="Fichier:   " + os.path.split(path)[1])
    get_path_label.configure(text=path)
    return path


def set():
    status_label.configure(text="lance !!!", fg_color="green")
    root.after(100,set)


def encrypt_file():
    path = get_path_label.cget('text')
    password = password_entry.get()
    try:
        if not password.strip():
            raise ValueError
        encrypt_pdf_files(path, password)
        status_label.configure(text="fichier crypté avec succès !!!", fg_color="green")
    except:
        if not path:
            messagebox.showerror("Ereur de cyptage", "veuiller choisir un fichier")
        elif not password:
            messagebox.showerror("Ereur de cyptage", "veuiller entrer un mot de passe ex: 123456")
        else:
            messagebox.showerror("Ereur de cyptage", "le fichier est déjà crypte")
        pass


def decrypt_file():
    path = get_path_label.cget('text')
    password = password_entry.get()
    try:
        if not path:
            raise ValueError
        if not password.strip():
            raise ValueError
        if decrypt_pdf_files(path,password)!="":
            raise ValueError
        status_label.configure(text="fichier décrypté avec succès !!!", fg_color="green")
    except:
        if not path:
            messagebox.showerror("Ereur de cyptage", "veuiller choisir un fichier")
        elif not password:
            messagebox.showerror("Ereur de cyptage", "veuiller entrer un mot de passe ex: 123456")
        elif decrypt_pdf_files(path,password):
            messagebox.showerror("Ereur de cyptage",decrypt_pdf_files(path,password) )


root.maxsize(700,470)
root.minsize(610,460)
root.title("Encrytp/Descrytpt Powered by ZONGO Edouard 66169083")
root.geometry("610x460+200+30")
set_default_color_theme("green")
label_info = CTkLabel(root, text="Crypter ou Décrypter vos fichiers PDF",
                      font=("Helcvetica", 30, "bold")).place(x=20, y=5)
label_browse = CTkLabel(root, text="Cliquer sur choisir fichier PDF",
                        font=("Helcvetica", 22, "bold")).place(x=10, y=85)
label_entry_pwd = CTkLabel(root, text="Entrer votre de passe ici:", font=("Helcvetica",
                                                                          22, "bold")).place(x=20, y=235)
password_entry = CTkEntry(root, placeholder_text="Entrer votre mot de passe", corner_radius=25,
                          font=("Helvetica", 20, "bold"),
                          width=300, height=40)
password_entry.place(x=300, y=230)

encrypt_button = CTkButton(root, text="Crypter le fichier", command=encrypt_file, corner_radius=25, width=180,
                           height=52, font=("Helvetica", 20))
encrypt_button.place(x=300, y=300)
decrypt_button = CTkButton(root, text="Décrypter le fichier", command=decrypt_file, corner_radius=25, width=180,
                           height=52, font=("Helvetica", 20))
decrypt_button.place(x=30, y=300)
browse_button = CTkButton(root, text="Choisir un fichier PDF", command=get_file_path, corner_radius=25, width=180,
                          height=45, font=("Helvetica", 20))
browse_button.place(x=340, y=80)
label_path = CTkLabel(root, text="", font=("Helvetica", 25, "bold"))
label_path.place(x=30, y=160)
variable = IntVar(root, value=0)
get_path_label = CTkLabel(root, text="", font=("Helvetica", 25, "bold"))
status_label = CTkLabel(root, text="", font=("Helvetica", 27))
status_label.place(x=100, y=380)
change_theme_color(root,10,y=430)
root.mainloop()